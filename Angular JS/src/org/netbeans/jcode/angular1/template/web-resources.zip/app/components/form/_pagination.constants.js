(function() {
    'use strict';

    angular
        .module('<%= angularAppName %>')
        .constant('paginationConstants', {
            'itemsPerPage': 20
        });
})();
