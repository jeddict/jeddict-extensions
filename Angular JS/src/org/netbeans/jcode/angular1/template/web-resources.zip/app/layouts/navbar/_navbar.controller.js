(function() {
    'use strict';

    angular
        .module('<%= angularAppName %>')
        .controller('NavbarController', NavbarController);

    NavbarController.$inject = ['$state', 'Auth', 'Principal', <%_ if(enableProfile) { _%>'ProfileService', <%_ } _%>'LoginService'];

    function NavbarController ($state, Auth, Principal, <%_ if(enableProfile) { _%>ProfileService, <%_ } _%>LoginService) {
        var vm = this;

        vm.isNavbarCollapsed = true;
        vm.isAuthenticated = Principal.isAuthenticated;
<%_ if(enableProfile) { _%>
        ProfileService.getProfileInfo().then(function(response) {
            vm.inProduction = response.inProduction;
            vm.swaggerEnabled = response.swaggerEnabled;
        });
<%_ } _%>
<%_ if(enableDocs) { _%>
        vm.swaggerEnabled = true;
<%_ } _%>
        vm.login = login;
        vm.logout = logout;
        vm.toggleNavbar = toggleNavbar;
        vm.collapseNavbar = collapseNavbar;
        vm.$state = $state;

        function login() {
            collapseNavbar();
            LoginService.open();
        }

        function logout() {
            collapseNavbar();
            Auth.logout();
            $state.go('home');
        }

        function toggleNavbar() {
            vm.isNavbarCollapsed = !vm.isNavbarCollapsed;
        }

        function collapseNavbar() {
            vm.isNavbarCollapsed = true;
        }
    }
})();
