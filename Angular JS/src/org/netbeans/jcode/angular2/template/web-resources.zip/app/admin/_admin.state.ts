import { Ng2StateDeclaration } from "ui-router-ng2";

export const adminState: Ng2StateDeclaration = {
    name: 'admin',
    abstract: true,
    parent: 'app'
};
