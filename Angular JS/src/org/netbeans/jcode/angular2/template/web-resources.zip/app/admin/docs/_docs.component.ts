import { Component } from '@angular/core';

@Component({
    selector: '<%=jhiPrefix%>-docs',
    templateUrl: './docs.component.html'
})
export class <%=jhiPrefixCapitalized%>DocsComponent {}
