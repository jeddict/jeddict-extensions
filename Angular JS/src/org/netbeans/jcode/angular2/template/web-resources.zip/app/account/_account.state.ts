import { Ng2StateDeclaration } from "ui-router-ng2";

export const accountState: Ng2StateDeclaration = {
    name: 'account',
    abstract: true,
    parent: 'app'
};
