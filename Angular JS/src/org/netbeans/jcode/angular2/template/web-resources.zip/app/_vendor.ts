/* tslint:disable */
<%_ if (useSass) { _%>
import '../content/scss/vendor.scss';
<%_} else { _%>
import '../content/css/vendor.css';
<%_ } _%>
