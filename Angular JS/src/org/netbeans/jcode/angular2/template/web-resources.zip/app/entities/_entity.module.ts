import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { UIRouterModule } from 'ui-router-ng2';
import { InfiniteScrollModule } from 'angular2-infinite-scroll';

import { <%=angular2AppName%>SharedModule } from '../shared';
import {
    entityState,
    /* needle-add-entity-to-module-import - add entity classes here */
} from './';

let ENTITY_STATES = [
    entityState,
    /* needle-add-entity-to-module-states - add entity state vars here */
];

@NgModule({
    imports: [
        <%=angular2AppName%>SharedModule,
        InfiniteScrollModule,
        UIRouterModule.forChild({ states: ENTITY_STATES })
    ],
    declarations: [
        /* needle-add-entity-to-module-declarations - add entity component classes here */
    ],
    entryComponents: [
        /* needle-add-entity-to-module-entryComponents - add entity dialog classes here */
    ],
    providers: [
        /* needle-add-entity-to-module-providers - add entity Service classes here */
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class <%=angular2AppName%>EntityModule {}

