import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

/* needle-add-entity-module-import - add entity modules imports here */

@NgModule({
    imports: [
        /* needle-add-entity-module - add entity modules here */
    ],
    declarations: [],
    entryComponents: [],
    providers: [],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class <%=angular2AppName%>EntityModule {}
