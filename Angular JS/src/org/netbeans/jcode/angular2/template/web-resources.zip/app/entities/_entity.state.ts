import { Ng2StateDeclaration } from 'ui-router-ng2';

export const entityState: Ng2StateDeclaration = {
    name: 'entity',
    abstract: true,
    parent: 'app'
};
